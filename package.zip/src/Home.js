import React from 'react';
import web from '../src/images/imgg.JPG';
import {NavLink} from 'react-router-dom';
import Common from './Common.js';

const Home=()=>{

	return (

		<>
		<Common name=" Capture Your Moments With "  visit="/service" imgsrc="https://picturecorrect-wpengine.netdna-ssl.com/wp-content/uploads/2018/11/home-studio-setup-tips-2.jpg"  btnname="Get Started"/>
		</>

		)
};


export default Home;
