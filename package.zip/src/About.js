import React from 'react';
import Common from './Common.js';
import web from '../src/images/imgg.JPG';

import Avatar from './Avatar';


const About=()=>{

	return (

		<>
		<Avatar/>
		</>
		
		)
};


export default About;
